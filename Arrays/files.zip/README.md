# DSA — Arrays

Solutions to array problems following **Striver's A2Z DSA Sheet** style.

Each solution contains:
- **Brute Force** — naive approach with explanation
- **Better** — intermediate approach (where applicable)
- **Optimal** — best approach with full code
- **Time & Space Complexity** for each approach
- **Dry Run** for the optimal solution

---

## Problems

| # | Problem | Difficulty | Key Concept |
|---|---------|-----------|-------------|
| 01 | [Remove Duplicates from Sorted Array](./01_remove_duplicates_sorted.md) | Easy | Two Pointers |
| 02 | [Left Rotate Array by One](./02_left_rotate_by_one.md) | Easy | Array Manipulation |
| 03 | [Left Rotate Array by K Places](./03_left_rotate_by_k.md) | Easy | Reversal Algorithm |
| 04 | [Move Zeros to End](./04_move_zeros_to_end.md) | Easy | Two Pointers |
| 05 | [Linear Search](./05_linear_search.md) | Easy | Searching |
| 06 | [Union of Two Sorted Arrays](./06_union_sorted_arrays.md) | Easy | Two Pointers |
| 07 | [Find Missing Number](./07_find_missing_number.md) | Easy | Math / XOR |
| 08 | [Maximum Consecutive Ones](./08_max_consecutive_ones.md) | Easy | Sliding Window |
| 09 | [Find the Number That Appears Once](./09_single_number.md) | Medium | XOR |
| 10 | [Longest Subarray with Sum K (Positives)](./10_longest_subarray_sum_k_positives.md) | Medium | Sliding Window |
| 11 | [Longest Subarray with Sum K (All Integers)](./11_longest_subarray_sum_k.md) | Medium | Prefix Sum + HashMap |

---

## Language
All solutions are written in **C++**.

---

## Reference
Problems sourced from [Striver's A2Z DSA Sheet](https://takeuforward.org/strivers-a2z-dsa-course/strivers-a2z-dsa-course-sheet-2/).
